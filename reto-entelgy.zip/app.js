var myContent = document.getElementById('root');

myContent.innerHTML = `<div id="content" >
                            <main id="main-content">
                                <card-list-pais></card-list-pais>    
                                
                            </main>
                        </div>`;

